<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KamalKalraFandu\\Providers\\KamalKalraFanduServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KamalKalraFandu\\Providers\\KamalKalraFanduServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);