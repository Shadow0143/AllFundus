<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FanduMe\\Providers\\FanduMeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FanduMe\\Providers\\FanduMeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);