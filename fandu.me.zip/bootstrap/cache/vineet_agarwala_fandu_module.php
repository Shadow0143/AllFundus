<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VineetAgarwalaFandu\\Providers\\VineetAgarwalaFanduServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VineetAgarwalaFandu\\Providers\\VineetAgarwalaFanduServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);