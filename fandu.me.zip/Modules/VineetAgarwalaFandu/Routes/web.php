<?php



// Route::prefix('vineet-agarwala')->group(function () {
    // Route::get('/', 'VineetAgarwalaFanduController@index');

    // Route::get('/', [App\Http\Controllers\CommonController::class, 'index'])->name('welcome');

    // Route::post('/submit-testimonial', 'MainController@submitTestimonial')->name('submitTestimonial');
    // Route::get('/intrest-details/{id}', 'MainController@intrestDetails')->name('intrestDetails');
    // Route::post('/add-intrest', 'MainController@addIntrest')->name('addIntrest');


    // Route::get('/testimonial-detail/{slug}/{id}', 'MainController@testimonialDetail')->name('testimonialDetail');
    // Route::post('/submit-contents', 'MainController@submitContents')->name('submitContents');
    // Route::get('/read-feature/{slug}', 'MainController@viewFeatures')->name('viewFeatures');
    // Route::get('/read-about-us', 'MainController@readAboutUs')->name('readAboutUs');
    // Route::get('/why-me', 'MainController@whyMe')->name('whyMe');
    // Route::get('/blogs', 'MainController@blogs')->name('blogs');
    // Route::post('/submit-tag', 'MainController@submitTag')->name('submitTag');
    // Route::get('/our-sites', 'MainController@ourSites')->name('ourSites');
// });