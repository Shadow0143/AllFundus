<?php $__env->startSection('title'); ?>
<title>Kamal Kalra</title>
<?php $__env->stopSection(); ?>


<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($data['section_name'] == 'Intro'): ?>
<div class="helloSec">
    <div class="iContainer">
        
        <div class="hsLeft">
            <p>
                <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty(Auth::user()->id)): ?>
                <?php if(Auth::user()->role=='owner'): ?>
                <?php if($item['section_item_name'] == 'Greeting'): ?>
            <form action="" id="greating_form">
                <input type="hidden" name="greating_id" id="greating_id" value="<?php echo e($item['id']); ?>">
                <input type="text" name="section_name" id="section_name" value="<?php echo e($item['section_item_value']); ?>"
                    class="text_style">
            </form>
            <?php endif; ?>
            <?php else: ?>
            <?php if($item['section_item_name'] == 'Greeting'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endif; ?>
            <?php else: ?>
            <?php if($item['section_item_name'] == 'Greeting'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Signature'): ?>
            <?php if(!empty(Auth::user()->id)): ?>
            <?php if(Auth::user()->role=='owner'): ?>
            <form action="">
                <input type="hidden" name="change_signature_id" id="change_signature_id" value="<?php echo e($item['id']); ?>">
                
                <span class="text-danger text-left">
                    <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" id="imgPreview" />
                </span>
            </form>
            <?php else: ?>
            <span>
                <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" />
            </span>
            <?php endif; ?>
            <?php else: ?>
            <span>
                <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" />
            </span>
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty(Auth::user()->id)): ?>
            <?php if(Auth::user()->role=='owner'): ?>
            <?php if($item['section_item_name'] == 'Degree'): ?>
            <form action="">
                <input type="hidden" name="section_descr_id" id="section_descr_id" value="<?php echo e($item['id']); ?>">
                <textarea name="section_descr" id="section_descr" cols="10" rows="5"
                    class="text_style"><?php echo e($item['section_item_value']); ?></textarea>
            </form>
            <?php endif; ?>
            <?php else: ?>
            <?php if($item['section_item_name'] == 'Degree'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endif; ?>
            <?php else: ?>
            <?php if($item['section_item_name'] == 'Degree'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <div class="socialFooter">
                <ul>
                    <li>
                        <a href=""><i class="ti-twitter-alt"></i></a>

                    </li>
                    <li>
                        <a href=""><i class="ti-facebook"></i></a>

                    </li>
                    <li>
                        <a href=""><i class="ti-linkedin"></i></a>

                    </li>
                    <li>
                        <a href=""><i class="ti-youtube"></i></a>

                    </li>
                </ul>
            </div>
        </div>
        <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['section_item_name'] == 'Profile Image'): ?>
        <div class="hsRight">
            <?php if(Auth::user()): ?>
            <?php if(!empty(Auth::user()->role=='owner')): ?>
            
            <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" id="profileimgPreview" />
            <?php else: ?>
            <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" />
            <?php endif; ?>
            <?php else: ?>
            <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" />
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php endif; ?>
<?php if($data['section_name'] == 'Biography'): ?>
<div class="bioSec">
    <div class="iContainer">
        <h3>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Title'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h3>
        <p>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Description'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
        <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['section_item_name'] == 'Read More Link'): ?>
        
        
        
        <a href="#" class="rmore">Know More</a>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php if($data['section_name'] == 'My Book'): ?>
<div class="myProSec">
    <div class="iContainer">
        <div class="blockHead">
            <div class="bhLeft">
                <div class="titleTag">
                    <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['section_item_name'] == 'Section Title'): ?>
                    <?php echo e($item['section_item_value']); ?>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h4>
                    <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['section_item_name'] == 'Section Sub Title'): ?>
                    <?php echo e($item['section_item_value']); ?>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h4>
                <p class="titleDesco">
                    <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['section_item_name'] == 'Section Description'): ?>
                    <?php echo e($item['section_item_value']); ?>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Image'): ?>
            <div class="bhRight">
                <img src="<?php echo e(asset('package')); ?>/<?php echo e($item['section_item_value']); ?>" />
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <h5>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Title'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h5>
        <p>
            <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['section_item_name'] == 'Description'): ?>
            <?php echo e($item['section_item_value']); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
        <?php $__currentLoopData = $data['section_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['section_item_name'] == 'Buy Now Link'): ?>
        <a href="<?php echo e($item['section_item_value']); ?>" class="rmore">Buy Now</a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="ctaSec">
    <div class="iContainer">
        <h4>Skip to the good part...</h4>
        <ul class="ctaList">
            <li><a href="">
                    <div class="ctaImage"><img src="<?php echo e(asset('new/images/socialbox/social01.png')); ?>" alt="cta1.jpg"></div>
                    <div class="ctaMatr"><i class="ti-twitter"></i>
                        <h5> My Tweets</h5>
                    </div>
                </a>
            </li>
            <li><a href="">
                    <div class="ctaImage"><img src="<?php echo e(asset('new/images/socialbox/social02.png')); ?>" alt="cta2.jpg"></div>
                    <div class="ctaMatr"><i class="ti-write"></i>
                        <h5> Recent Posts</h5>
                    </div>
                </a>
            </li>
            <li><a href="">
                    <div class="ctaImage"><img src="<?php echo e(asset('new/images/socialbox/social04.png')); ?>" alt="cta3.jpg"></div>
                    <div class="ctaMatr"><i class="ti-face-smile"></i>
                        <h5> Social Events</h5>
                    </div>
                </a>
            </li>
            <li><a href="">
                    <div class="ctaImage"><img src="<?php echo e(asset('new/images/socialbox/social03.png')); ?>" alt="cta4.jpg"></div>
                    <div class="ctaMatr"><i class="ti-marker-alt"></i>
                        <h5>My Book</h5>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div><?php /**PATH /home/billu/Data/Professional/Laravel/AllFundus/resources/views/rightviews/kamalCommon.blade.php ENDPATH**/ ?>