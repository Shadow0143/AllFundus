   
<?php if(!empty($post)): ?>
<div class="iContainer" id="mainDiv">
    <div class="postsDisplay" >
        <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-12 col-md-12 col-sm-12 embeded_post " id="main_post_div<?php echo e($post->id); ?>">
            <div class="post_remove">
                <span class="post_date"><?php echo e(date('d F Y',strtotime($post->created_at))); ?></span>
                <?php if(Auth::user() && Auth::user()->role=='owner'): ?>
                <a href="javaScript:void(0);" class="btn_remove_post" data-id="<?php echo e($post->id); ?>"><i
                        class="ti-close"></i></a>
                <?php endif; ?>

            </div>
            <?php if(!empty($post->title)): ?>
            <h3 class="post_title">
                <?php if(Request::segment(1) !=''): ?>
                <a
                    href="<?php echo e(route('segmentpostDetails',['segment'=>Request::segment(1),'id'=>$post->id])); ?>"><?php echo e(ucfirst($post->title)); ?></a>

                <?php else: ?>
                <a href="<?php echo e(route('fandupostDetails',['id'=>$post->id])); ?>"><?php echo e(ucfirst($post->title)); ?></a>

                <?php endif; ?>

            </h3>
            <?php endif; ?>

            <?php if(!empty($post->sub_title)): ?>
            <h4><?php echo e(ucfirst($post->sub_title)); ?></h4>
            <?php endif; ?>


            <?php if(!empty($post->title)): ?>
            <?php if(!empty($post['post_content'])): ?>
            <?php
            $rem_len = str_word_count($post['post_content']);
            $extract_data = implode(' ', array_slice(explode(' ', $post['post_content']), 0, 50));

            ?>
            <?php if($rem_len > 50): ?>
            <p class="post_details"><?php echo $extract_data; ?>...
            </p>

            <?php if(Request::segment(1) !=''): ?>
            <a href="<?php echo e(route('segmentpostDetails',['segment'=>Request::segment(1),'id'=>$post->id])); ?>">Read more</a>

            <?php else: ?>
            <a href="<?php echo e(route('fandupostDetails',['id'=>$post->id])); ?>">Read more</a>

            <?php endif; ?>
            <?php else: ?>
            <p class="post_details"><?php echo $post['post_content']; ?></p>
            <?php endif; ?>

            <?php endif; ?>

            <?php else: ?>
            <p class="post_details"><?php echo $post['post_content']; ?></p>
            <?php endif; ?>

            <?php if(count($post->post_image) == 1): ?>

            <div class="light_gallery gitem" id="lightGallery">
                <?php $__currentLoopData = $post->post_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" data-sub-html="<?php echo e($post->title); ?>">
                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"
                        class="img-responsive">
                    <div class="more_img_overlay">

                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if(count($post->post_image) == 2): ?>

            <div class="light_gallery gitem2" id="lightGallery">
                <?php $__currentLoopData = $post->post_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" data-sub-html="<?php echo e($post->title); ?>">
                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"
                        class="img-responsive">
                    <div class="more_img_overlay">

                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if(count($post->post_image) == 3): ?>

            <div class="light_gallery gitem3" id="lightGallery">
                <?php $__currentLoopData = $post->post_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" data-sub-html="<?php echo e($post->title); ?>">
                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"
                        class="img-responsive">
                    <div class="more_img_overlay">

                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if(count($post->post_image) == 4): ?>

            <div class="light_gallery gitem4" id="lightGallery">
                <?php $__currentLoopData = $post->post_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" data-sub-html="<?php echo e($post->title); ?>">
                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"
                        class="img-responsive">
                    <div class="more_img_overlay">

                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if(count($post->post_image) >= 5): ?>

            <div class="light_gallery gitem5" id="lightGallery">
                <?php $__currentLoopData = $post->post_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" data-sub-html="<?php echo e($post->title); ?>">
                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"
                        class="img-responsive">
                    <div class="more_img_overlay">
                        <span>+<?php echo e(count($post->post_image)-5); ?></span>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <div class="postFtr">
                <ul class="pftrList">
                    <!-- Button trigger modal -->
                    <li>


                        <?php if(!Auth::user()): ?>
                        <a href="javaScript:void(0);" onclick="goolgelogin()" id="likeremove<?php echo e($post['id']); ?>"
                            title="like" class="likeremove<?php echo e($post['id']); ?> ">
                            <i class="ti-heart"></i> <span> <?php echo e($post->likes); ?></span>
                        </a>
                        <?php else: ?>
                        <a href="javaScript:void(0);" id="datashow<?php echo e($post['id']); ?>"
                            class="text-danger datashow<?php echo e($post['id']); ?> " title="liked !" style="display: none">
                            <i class="ti-heart"></i>
                            <span id="datalike<?php echo e($post['id']); ?>" class="datalike<?php echo e($post['id']); ?>">
                                <?php echo e($post->likes); ?></span>
                        </a>
                        <?php if($post->likeExist): ?>
                        <a href="javaScript:void(0);" id="likeshow<?php echo e($post['id']); ?>"
                            class="text-danger likeshow<?php echo e($post['id']); ?>" title="liked !">
                            <i class="ti-heart"></i> <span> <?php echo e($post->likes); ?></span>
                        </a>
                        <?php else: ?>
                        <a href="javaScript:void(0);" <?php if(Auth::user()): ?> onclick="likes('<?php echo e($post['id']); ?>')" <?php else: ?>
                            onclick="goolgelogin()" <?php endif; ?> id="likeremove<?php echo e($post['id']); ?>" title="like"
                            class="likeremove<?php echo e($post['id']); ?>">
                            <i class="ti-heart"></i> <span> <?php echo e($post->likes); ?></span>
                        </a>
                        <?php endif; ?>

                        <?php endif; ?>
                    </li>

                    <li>
                        <a href="javaScript:void(0);" class="comment_icon" data-id="<?php echo e($post['id']); ?>"
                            data-toggle="collapse" data-target="#comments_view<?php echo e($post['id']); ?>">

                            <i class="ti-comment"></i>
                            <span id="commentCount-<?php echo e($post->id); ?>"><?php echo e($post['total_comment']); ?>

                            </span>
                        </a>
                        <input type="hidden" id="commentCountbox<?php echo e($post->id); ?>" value="0">
                    </li>
                    <li><a href="">
                            <?php if(is_array($post->categ) || is_object($post->categ)): ?>
                            <i class="ti-flag-alt"></i>
                            <?php $__currentLoopData = $post->categ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span> <a
                                    href="<?php echo e(route('filterByCategory',['type'=>$val_tag])); ?>"><?php echo e(ucfirst($val_tag)); ?></a>
                            </span> &nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </a>
                    </li>
                    <div id="comments_view<?php echo e($post['id']); ?>" class="collapse comment_box">
                        <div>
                            <?php if(!empty(Auth::user())): ?>
                            <form action="" id="commet_form<?php echo e($post['id']); ?>" class="comment_form" method="POST">
                                <div class="comment_input">
                                    <input type="hidden" name="post_new_id" id="post_new_id">
                                    <input type="hidden" name="token" id="token" value=<?php echo e(csrf_token()); ?>>
                                    <input type="text" name="" id="comment_message<?php echo e($post['id']); ?>"
                                        class="form-control" placeholder="Write comments">
                                </div>
                                <button type="submit" onClick="submitForm(`<?php echo e($post->id); ?>`)">
                                    <i class="ti-location-arrow"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                            <div id="commentId-<?php echo e($post->id); ?>" class="comment_history">
                                <?php $__empty_2 = true; $__currentLoopData = $post['all_comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div id="comment_row<?php echo e($post->id); ?><?php echo e($comm->id); ?>">

                                    <div class="com_inner" id="comment_row<?php echo e($post->id); ?><?php echo e($comm->id); ?>">
                                        <div class="com_user">
                                            <h4><?php echo e($comm->user_name); ?></h4>
                                            <p><?php echo e($comm->comments); ?></p>
                                        </div>
                                        <?php if(Auth::user()): ?>
                                        <?php if(Auth::user()->role=='owner'): ?>
                                        <a href="javaScript:void(0);" data-id="<?php echo e($comm->id); ?>"
                                            class="post_com_delete"
                                            onclick="deleteComment('<?php echo e($comm->id); ?>,<?php echo e($post->id); ?>')">
                                            <i class="ti-close"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <ul class="com_action">
                                            <li>

                                                <?php echo e($comm->created_at->diffForHumans()); ?>

                                            </li>
                                            <?php if(Auth::user()): ?>
                                            <?php if(Auth::user()->role=='owner'): ?>
                                            <li>
                                                <a data-toggle="collapse" data-target="#reply_view<?php echo e($comm['id']); ?>"
                                                    href="javaScript:void(0);" title="Reply">
                                                    Reply
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <div class="collapse com_inner" id="reply_view<?php echo e($comm->id); ?>">
                                        <form class="comment_form reply_form" action="" id="reply<?php echo e($comm->id); ?>">
                                            <div class="comment_input">
                                                <input type="hidden" name="token" id="token" value=<?php echo e(csrf_token()); ?>>

                                                <input type="hidden" name="reply_for_comment" id="reply_for_comment"
                                                    value="<?php echo e($comm->id); ?>">
                                                <input type="text" name="reply_message"
                                                    id="reply_message<?php echo e($comm->id); ?>" class="form-control"
                                                    placeholder="Reply on comment">
                                            </div>
                                            <button type="submit" onclick="submitReply('<?php echo e($comm->id); ?>')">
                                                <i class="ti-location-arrow"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div id="replyview<?php echo e($comm->id); ?>" style="margin-left: 20px;">
                                        <?php $__currentLoopData = $comm['all_reply']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="com_inner">
                                            <div class="com_user">
                                                <h4>Replied by : <?php echo e($comm->user_name); ?></h4>
                                                <p><?php echo e($reply->replys); ?></p>
                                            </div>
                                            <ul class="com_action">
                                                <li>
                                                    <?php echo e($reply->created_at->diffForHumans()); ?>

                                                </li>
                                            </ul>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="text-center" id="nocomment-<?php echo e($post->id); ?>">No comments.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <li>
                        <a href="">
                            <?php if(is_array($post->tags) || is_object($post->tags)): ?>
                            <i class="ti-tag"></i>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('filterByTag',['type'=>$val_tag])); ?>">

                                
                                    <span> <?php echo e(ucfirst($val_tag)); ?></span> </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </a>
                    </li>
                </ul>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-lg-12 col-md-12 text-center mt-5">
            <p class="text-danger nomore">No data found</p>
        </div>
        <?php endif; ?>
    
        <div id="result-data">

        </div>
    </div>
</div>

<?php endif; ?><?php /**PATH /home/billu/Data/Professional/Laravel/AllFundus/resources/views/leftviews/commonleft.blade.php ENDPATH**/ ?>