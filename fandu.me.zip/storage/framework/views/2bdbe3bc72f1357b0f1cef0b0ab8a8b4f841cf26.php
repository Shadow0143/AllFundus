<footer class="footer_section">

    <div class="footertop45">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div class="logofooter"><a href="#">FANDU</a></div>

                <div class="footerinfo">
                    <p>
                        123A High Street Kolkata, West Bengal India
                    </p>

                    <div class="rightinfo56">
                        <a href="">+91 (0)1234567890</a>
                        <a href="">hello@fandu.me</a>
                    </div>
                </div>

            </div>

            <div class="col-md-6 col-sm-6">
                <div class="footerblock">
                    <h2>Explore</h2>
                    <ul class="footmenu">
                        <li>
                            <a href="#">About Fandu</a>
                        </li>
                        <li>
                            <a href="#">Why u need personal website</a>
                        </li>
                        <li>
                            <a href="#">Why fandu</a>
                        </li>
                        <li>
                            <a href="#">Our differentiation with other options</a>
                        </li>
                        <li>
                            <a href="#">Features</a>
                        </li>
                        <li>
                            <a href="#">Existing sites</a>
                            
                        </li>

                    </ul>

                    <div class="socialmedia">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="btmfooter">
        <p>© 2022 Fandu.me. All rights reserved.</p>
    </div>
</footer><?php /**PATH /home/billu/Data/Professional/Laravel/AllFundus/resources/views/layouts/footer.blade.php ENDPATH**/ ?>